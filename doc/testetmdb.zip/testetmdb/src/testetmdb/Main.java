/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package testetmdb;

import java.io.IOException;
import java.util.List;
import net.sf.jtmdb.*;
import pucrs.imdb.*;

/**
 *
 * @author 10049190
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        // LEITURA DO IMDB Top 250

        ArquivoFilmes arqFilmes = new ArquivoFilmes();
        arqFilmes.preencherPorArquivo("imdb-short20102.txt");
        ListaFilmes listaFilmes = arqFilmes.getListaFilmes();
        System.out.println(listaFilmes.getTotalFilmes());
        for(Filme f: listaFilmes)
            System.out.println(f);

        // ACESSO ONLINE AO TMDB

        try {
            GeneralSettings.setApiKey("86a9671ee20b7406c5a0c15ca60824cd");
            List<Movie> lista = Movie.search("Inception");

            System.out.println("Resultados: " + lista.size());
            Movie mymovie = lista.get(0);

            // Mostra nome e ID no TMDb
            System.out.println(mymovie.getName());
            mymovie = Movie.getInfo(mymovie.getID());

            // Mostra os gêneros do filme
            System.out.println(mymovie.getGenres().size());
            for (Genre g : mymovie.getGenres()) {
                System.out.println(g.getName());
            }

            // Mostra o elenco, e função de cada um
            for(CastInfo c : mymovie.getCast()) {
                System.out.println(c.getName()+  " - " + c.getJob() + " - " + c.getCharacterName());
            }

            // Exemplo de como obter uma URL para um dos pôsters do filme
            // (no caso, o primeiro da lista)
            MoviePoster poster = (MoviePoster) mymovie.getImages().posters.toArray()[0];
            System.out.println(poster.getSmallestImage());
            
        } catch (Exception e) {
            System.out.println("Erro accessando a rede!");
            e.printStackTrace();
        }
    }
}
